// app.js
require('dotenv').config()
const express = require('express');
const app = express();
const userRoutes = require('./routes/user');
const playerRoutes = require('./routes/player');
const coachRoutes = require('./routes/coach');
const trainingSessionRoutes = require('./routes/trainingSession');
const registrationRoutes = require('./routes/registration');
const feedbackRoutes = require('./routes/feedback');
const franchiseRoutes = require('./routes/franchise');
const facilityRoutes = require('./routes/facility');
const equipmentRoutes = require('./routes/equipment');

app.use(express.json());

app.use('/users', userRoutes);
app.use('/players', playerRoutes);
app.use('/coaches', coachRoutes);
app.use('/trainingSessions', trainingSessionRoutes);
app.use('/registrations', registrationRoutes);
app.use('/feedbacks', feedbackRoutes);
app.use('/franchises', franchiseRoutes);
app.use('/facilities', facilityRoutes);
app.use('/equipment', equipmentRoutes);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});